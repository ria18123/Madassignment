package com.collegeproj.journeyjournal;

public class Userinfo {

    public String id, email, address, fullname, phone, password;
}



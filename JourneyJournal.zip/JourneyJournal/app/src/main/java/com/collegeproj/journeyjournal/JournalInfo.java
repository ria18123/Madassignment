package com.collegeproj.journeyjournal;

import java.io.Serializable;

public class JournalInfo implements Serializable {
    public String id, title, date, description, location,userid;
    public byte[] image;
}

package com.collegeproj.journeyjournal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class RecyclerViewActivity extends AppCompatActivity {

    RecyclerView rcv;
    myAdapter Adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycleview);
        setTitle("Recycler and card View Demo");

        rcv = (RecyclerView) findViewById(R.id.recview);
        rcv.setLayoutManager(new LinearLayoutManager(this));

        Adapter = new myAdapter(dataqueue());
        rcv.setAdapter(Adapter);

    }
    public ArrayList<Model> dataqueue()
    {
        ArrayList<Model> holder=new ArrayList<>();
        Model ob1=new Model();
        ob1.setHeader("C Programming");
        ob1.setDesc("Desktop Programming");
        ob1.setImgname(R.drawable.ic_baseline_person_24);
        holder.add(ob1);

        Model ob2=new Model();
        ob2.setHeader("C++ Programming");
        ob2.setDesc("Desktop Programming Language");
        ob2.setImgname(R.drawable.ic_baseline_person_24);
        holder.add(ob2);

        Model ob3=new Model();
        ob3.setHeader("C++ Programming");
        ob3.setDesc("Desktop Programming Language");
        ob3.setImgname(R.drawable.ic_baseline_person_24);
        holder.add(ob3);

        Model ob4=new Model();
        ob4.setHeader("C++ Programming");
        ob4.setDesc("Desktop Programming Language");
        ob4.setImgname(R.drawable.ic_baseline_person_24);
        holder.add(ob4);


        Model ob5=new Model();
        ob5.setHeader("C++ Programming");
        ob5.setDesc("Desktop Programming Language");
        ob5.setImgname(R.drawable.ic_baseline_person_24);
        holder.add(ob5);


        Model ob6=new Model();
        ob6.setHeader("C++ Programming");
        ob6.setDesc("Desktop Programming Language");
        ob6.setImgname(R.drawable.ic_baseline_person_24);
        holder.add(ob6);

        return holder;

    }
}
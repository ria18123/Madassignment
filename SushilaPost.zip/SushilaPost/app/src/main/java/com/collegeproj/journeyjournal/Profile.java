package com.collegeproj.journeyjournal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Profile extends AppCompatActivity {

    TextView profile_username, profile_slogan, profile_personal, profile_address, profile_place, profile_location, profile_mail, profile_gmail, profile_phone, profile_number, profile_date, profile_birth ;
    ImageView profile_person, profile_home, profile_envelope, profile_telephone, profile_calender, profile_arrow, profile_edit ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        profile_username = (TextView) findViewById(R.id.profile_username);
        profile_slogan = (TextView) findViewById(R.id.profile_slogan);
        profile_personal = (TextView) findViewById(R.id.profile_personal);
        profile_address = (TextView) findViewById(R.id.profile_address);
        profile_place = (TextView) findViewById(R.id.profile_place);
        profile_location = (TextView) findViewById(R.id.profile_location);
        profile_mail = (TextView) findViewById(R.id.profile_mail);
        profile_gmail = (TextView) findViewById(R.id.profile_gmail);
        profile_phone = (TextView) findViewById(R.id.profile_phone);
        profile_number = (TextView) findViewById(R.id.profile_number);
        profile_date = (TextView) findViewById(R.id.profile_date);
        profile_birth = (TextView) findViewById(R.id.profile_birth);
        profile_person = (ImageView) findViewById(R.id.profile_person);
        profile_home = (ImageView) findViewById(R.id.profile_home);
        profile_envelope = (ImageView) findViewById(R.id.profile_envelope);
        profile_telephone = (ImageView) findViewById(R.id.profile_telephone);
        profile_calender = (ImageView) findViewById(R.id.profile_calender);
        profile_arrow = (ImageView) findViewById(R.id.profile_arrow);
        profile_edit = (ImageView) findViewById(R.id.profile_edit);

        profile_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Profile.this, editprofile.class));
            }
        });

    }
}
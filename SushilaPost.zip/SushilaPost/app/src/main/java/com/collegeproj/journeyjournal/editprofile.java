package com.collegeproj.journeyjournal;

public class editprofile {

}
